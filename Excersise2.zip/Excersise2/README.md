# Experiment 2 
------

> * code: include source code,type in "python MLP.py" in cmd to run source code.
> * result: include result file